--STEPS TO INSTALL/RUN--

1) Install node.js with all the dependencies intact.
2) Install Playwright with the help of npm and also chromium browser required by playwright.
3) In the price-scraper folder, run cmd and type "node server.mjs" to start the server/
4) Once the server start, go to the URL mentioned in the CMD.
5) Type the name of product you want to compare price.
